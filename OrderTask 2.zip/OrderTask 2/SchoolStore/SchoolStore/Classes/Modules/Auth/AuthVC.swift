// HxH School iOS Pass
// Copyright © 2021 Heads and Hands. All rights reserved.
//

import UIKit

class AuthVC: UIViewController {
    // MARK: Lifecycle

    let shape = CAShapeLayer()
    override func viewDidLoad() {
        super.viewDidLoad()

        let circlePath = UIBezierPath(arcCenter: loginField.center, radius: 14, startAngle: 0, endAngle: .pi * 2, clockwise: true)
    
        shape.path = circlePath.cgPath
        shape.lineWidth = 3
        shape.strokeColor = UIColor.white.cgColor
        shape.fillColor = UIColor.clear.cgColor
        shape.strokeEnd = 0
        signInButton.layer.addSublayer(shape)
        localizable()
    }
    
    @objc func didTapBtn() {
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.toValue = 1
        shape.add(animation, forKey: "animation")
        animation.duration = 2.5
        animation.fillMode = .forwards
        shape.add(animation, forKey: "animation" )
    }

    // MARK: Internal
    
    
    @IBOutlet weak var stView: UIStackView!
    
    @IBOutlet var loginField: InputField!

    @IBOutlet var passwordField: InputField!

    @IBOutlet var signInButton: UIButton!

    func setup(with authService: AuthService, _ snacker: Snacker) {
        self.authService = authService
        self.snacker = snacker
    }

    @IBAction func signInPressed(_: Any) {
        guard let user = loginField.text, let password = passwordField.text else {
            return
        }
        if user.isEmpty {
            loginField.error = L10n.Common.emptyField
        } else if password.isEmpty {
            passwordField.error = L10n.Common.emptyField
        } else {
            authService?.authenticate(user: user, with: password, completion: { [weak self] (result: Result<String, Error>) in
                switch result {
                case .success:
                    self!.signInButton.setTitle("", for: .normal)
                    self!.signInButton.isEnabled = false
                    self!.signInButton.addTarget(self, action: #selector(self!.didTapBtn), for: .allEvents)
                   
                    DispatchQueue.main.asyncAfter(deadline: .now()+2, execute: {
                                                    UIApplication.shared.windows.first(where: { $0.isKeyWindow })?.rootViewController = VCFactory.buildTabBarVC()})
                case let .failure(error):
                    self?.handle(error: error)
                }
            })
        }
    }

    // MARK: Private

    private var snacker: Snacker?

    private var authService: AuthService?

    private func handle(error: Error) {
        snacker?.show(snack: error.localizedDescription, with: .error)
        if let networkError = error as? Errors {
            switch networkError {
            case let .failedResponse(_, fields):
                fields?.forEach { field in
                    switch field.field {
                    case "login":
                        self.loginField.error = field.message
                    default:
                        break
                    }
                }
            default:
                break
            }
        }
    }

    private func localizable() {
        loginField.title = L10n.Auth.login
        passwordField.title = L10n.Auth.password
        signInButton.setTitle(L10n.Auth.action, for: .normal)
    }
}
