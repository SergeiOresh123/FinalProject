// HxH School iOS Pass
// Copyright © 2021 Heads and Hands. All rights reserved.
//

import UIKit
import AutoLayoutSugar
import Kingfisher

class ProfileVC: UIViewController {
    
    private var authService: AuthService?
    private var snacker: Snacker?
    var profile: Profile?
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        tabBarController?.tabBar.selectedItem?.title = L10n.Profile.title
        
        view.addSubview(topView)
        view.addSubview(bottomView)
        topView.addSubview(name)
        topView.addSubview(occupation)
        topView.addSubview(mainImageView)
        bottomView.addSubview(ordersButton)
        bottomView.addSubview(settingsButton)
        bottomView.addSubview(logOutButton)
        logOutButton.addSubview(logOutLabel)
        settingsButton.addSubview(settingsLabel)
        ordersButton.addSubview(historyLabel)
        
        logOutLabel.top(70).centerX()
        settingsLabel.top(70).centerX()
        historyLabel.top(70).centerX()
        
        topView.top().left().right().height(400)
        topView.backgroundColor = Asset.navBlue.color
        
        bottomView.top(400).left().right().bottom()
        bottomView.backgroundColor = .systemGray5
        
        mainImageView.top(150).centerX().height(120).width(120)
        mainImageView.layer.cornerRadius = 60
        mainImageView.clipsToBounds = true
        
        name.centerX().top(to: .bottom(16), of: mainImageView)
        name.textColor = .white
        
        occupation.centerX().top(to: .bottom(16), of: name)
        occupation.textColor = .white
        
        ordersButton.top(to: .bottom(24), of: topView).left(30).height(99).width(99)
        settingsButton.top(to: .bottom(24), of: topView).left(to: .right(16), of: ordersButton).height(99).width(99)
        logOutButton.top(to: .bottom(24), of: topView).left(to: .right(16), of: settingsButton).height(99).width(99)
        
        logOutButton.addTarget(self, action: #selector(logOutPressed), for: .touchUpInside)
        ordersButton.addTarget(self, action: #selector(historyPressed), for: .touchUpInside)
        settingsButton.addTarget(self, action: #selector(settingsPressed), for: .touchUpInside)
        
        authService?.getProfile(completion: {(result: Result<Profile,Error>) in
            switch result {
            case let .success(prof):
                self.profile = prof
            case let .failure(error):
                print(error)
            }
            })
        
        guard let n = profile?.name else {return}
        guard let sn = profile?.surname else {return}
        guard let profession = profile?.occupation else {return}
        
        if let avatar = profile?.avatarUrl, let urlAvatar = URL(string: avatar) {
            let contentImageResource = ImageResource(downloadURL: urlAvatar, cacheKey: avatar)
            mainImageView.kf.setImage(
                with: contentImageResource,
                placeholder: Asset.itemPlaceholder.image,
                options: [
                    .transition(.fade(0.2)),
                    .forceTransition,
                    .cacheOriginalImage,
                    .keepCurrentImageWhileLoading,
                ]
            )
        } else {
            mainImageView.image = Asset.itemPlaceholder.image
        }
        name.text = n + " " + sn
        occupation.text = profession
        

        // Do any additional setup after loading the view.
    }

    /*
     // MARK: - Navigation

     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
     }
     */

    // MARK: Internal

    var dataService: DataService?
    
    func setup(with authService: AuthService, _ snacker: Snacker, dataService: DataService) {
        self.authService = authService
        self.snacker = snacker
        self.dataService = dataService
    }
    
    @objc func logOutPressed() {
        dataService?.appState.accessToken = nil
        UIApplication.shared.windows.first(where: { $0.isKeyWindow })?.rootViewController = VCFactory.buildAuthVC()
    }
    
    @objc func historyPressed() {
        self.tabBarController?.selectedIndex = 1
    }
    
    @objc func settingsPressed() {
        self.navigationController?.pushViewController(VCFactory.builSettingsVC(with: profile!), animated: true)
    }
    
    private lazy var topView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var bottomView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var mainImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var name: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 24, weight: .medium)
        return label
    }()
    
    private lazy var logOutLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = "\(L10n.Btn.logout)"
        label.textColor = .white
        return label
    }()
    
    private lazy var settingsLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = "\(L10n.Settings.title)"
        label.textColor = .black
        return label
    }()
    
    private lazy var historyLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = "\(L10n.History.title)"
        label.textColor = .black
        return label
    }()
    
    private lazy var occupation: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .medium)
        return label
    }()
    
    private lazy var ordersButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        let image = UIImage(systemName: "bookmark.fill")
        let tintedImage = image?.withRenderingMode(.alwaysTemplate)
        button.setImage(tintedImage, for: .normal)
        button.tintColor = UIColor.black
        button.backgroundColor = .white
        button.layer.cornerRadius = 16
        return button
    }()
    
    private lazy var settingsButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        let image = UIImage(systemName: "gearshape.2")
        let tintedImage = image?.withRenderingMode(.alwaysTemplate)
        button.setImage(tintedImage, for: .normal)
        button.tintColor = UIColor.black
        button.backgroundColor = .white
        button.layer.cornerRadius = 16
        return button
    }()
    
    private lazy var logOutButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        let image = UIImage(systemName: "arrowshape.turn.up.right.fill")
        let tintedImage = image?.withRenderingMode(.alwaysTemplate)
        button.setImage(tintedImage, for: .normal)
        button.tintColor = UIColor.white
        button.backgroundColor = UIColor(red: 1.0, green: 0.321, blue: 0.321, alpha: 1.0)
        button.layer.cornerRadius = 16
        return button
    }()
    
    
}
