//
//  SettingsView.swift
//  SchoolStore
//
//  Created by Heads on 29.10.2021.
//

import AutoLayoutSugar
import Kingfisher
import UIKit

final class SettingsView: UIView {
    
    var profile: Profile?
    var avatar: String?
    
    var navigationController: UINavigationController?
    
    var snacker: Snacker?
    
    var nameSave: String!
    var surnameSave: String!
    var occupationSave: String!
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        translatesAutoresizingMaskIntoConstraints = false
    
        setup()
       
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
        
    }
    
    func fillWith(profile: Profile?) {
        guard let profile = profile else {
            return
        }
        
        nameField.text = profile.name
        surnameField.text = profile.surname
        occupationField.text = profile.occupation
        
        nameSave = nameField.text ?? ""
        surnameSave = surnameField.text ?? ""
        occupationSave = occupationField.text ?? ""
        
        if let avatar = profile.avatarUrl, let urlAvatar = URL(string: avatar) {
            let contentImageResource = ImageResource(downloadURL: urlAvatar, cacheKey: avatar)
            mainImageView.kf.setImage(
                with: contentImageResource,
                placeholder: Asset.itemPlaceholder.image,
                options: [
                    .transition(.fade(0.2)),
                    .forceTransition,
                    .cacheOriginalImage,
                    .keepCurrentImageWhileLoading,
                ]
            )
        } else {
            mainImageView.image = Asset.itemPlaceholder.image
        }
        
        avatar = profile.avatarUrl
     
    }
    
    private var settingsService = CoreFactory.buildSettingsService()
    
    private lazy var mainImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var nameField: InputField = {
        let nf = InputField()
        nf.translatesAutoresizingMaskIntoConstraints = false
        return nf
    }()
    
    private lazy var surnameField: InputField = {
        let sf = InputField()
        sf.translatesAutoresizingMaskIntoConstraints = false
        return sf
    }()
    
    private lazy var changeBtn: UIButton = {
          let button = UIButton()
          button.translatesAutoresizingMaskIntoConstraints = false
          button.tintColor = .white
          button.setTitle("\(L10n.Btn.change)", for: .normal)
          button.backgroundColor = .blue
          button.layer.cornerRadius = 8
          return button
      }()
    
    public lazy var occupationField: InputField = {
        let of = InputField()
        of.translatesAutoresizingMaskIntoConstraints = false
        return of
    }()
    
    public lazy var occupationOtherField: InputField = {
        let of = InputField()
        of.translatesAutoresizingMaskIntoConstraints = false
        return of
    }()
    
    @objc private func changeSettings() {
        
        guard  let name = nameField.textField.text,
               let surname = surnameField.textField.text,
               let occupation = occupationField.textField.text,
               let otherOccupation = occupationOtherField.textField.text
        else {return}
        
        if name == "" {
            
        nameField.error = L10n.Common.emptyField
        
        }
        else if surname == "" {
            
        surnameField.error = L10n.Common.emptyField
        
        }
        else if occupation == "" {
            
        occupationField.error = L10n.Common.emptyField
        
        }
        else if otherOccupation == "" {
            
        occupationOtherField.error = L10n.Common.emptyField
        
        }
        
        if surname != "" && occupation != "" && name != "" && (name != nameSave || surname != surnameSave || occupation != occupationSave) {
            if (occupation != "Другое") || (occupation == "Другое" && otherOccupation != "") {
                settingsService.userChange(name: name, surname: surname, occupation: occupation, avatar: avatar, completion: { [weak self] result in
                    guard let self = self else {
                        return
                    }
                    switch result {
                    case .success:
                        self.navigationController?.popToRootViewController(animated: true)
                    case let .failure(error):
                        self.snacker?.show(snack: error.localizedDescription, with: .error)
                    }
                })
                
            }
        }
    
    }
    
    private func setup() {
        
        addSubview(mainImageView)
        addSubview(nameField)
        addSubview(surnameField)
        addSubview(occupationField)
        addSubview(occupationOtherField)
        addSubview(changeBtn)
        changeBtn.left(16).right(16).bottom(100)
        mainImageView.top(200).centerX().height(120).width(120)
        mainImageView.layer.cornerRadius = 60
        mainImageView.clipsToBounds = true
        
        nameField.top(to: .bottom(32), of: mainImageView).left(16).right(16)
        surnameField.top(to: .bottom(32), of: nameField).left(16).right(16)
        occupationField.top(to: .bottom(32), of: surnameField).left(16).right(16)
        occupationOtherField.top(to: .bottom(32), of: occupationField).left(16).right(16)
        
        occupationOtherField.isHidden = true
        
        nameField.title = L10n.EditProfile.name
        surnameField.title = L10n.EditProfile.surname
        occupationField.title = L10n.EditProfile.occupation
        occupationOtherField.title = L10n.EditProfile.occupationOther
        
        changeBtn.addTarget(self, action: #selector(changeSettings), for: .touchUpInside)
            
    }

}

