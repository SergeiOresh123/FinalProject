//
//  SettingsVC.swift
//  SchoolStore
//
//  Created by Heads on 29.10.2021.
//

import AutoLayoutSugar
import Foundation
import UIKit

final class SettingsVC: UIViewController {
    
override func viewDidLoad() {
super.viewDidLoad()
    view.backgroundColor = .white
    view.addSubview(contentView)
    contentView.top().bottom().left().right()
    
    title = L10n.Edit.action
    
    contentView.navigationController = navigationController
    professionField.textField.addTarget(self, action: #selector(editProfile), for: [.allEditingEvents, .allTouchEvents] )
    
}
    private lazy var professionField = contentView.occupationField
    
    private lazy var professionOtherField = contentView.occupationOtherField
    
    private lazy var contentView: SettingsView = {
        let contentView = SettingsView()
        contentView.translatesAutoresizingMaskIntoConstraints = false
        return contentView
    }()
    
    @objc
    func specializationDidTap(_ sender: UIButton) {
        
        professionField.text = sender.titleLabel?.text
        
        if professionField.text == "Другое"  {
            
            professionOtherField.isHidden = false
        }
        else {
            professionOtherField.isHidden = true
        }
        
        presentedViewController?.dismiss(animated: true, completion: nil)
        
    }
    
    @objc func editProfile() {
        let array = [
            "Разработчик",
            "Тестировщик",
            "Маркетолог",
            "Другое",
        ]
        let view = UIStackView()
        view.axis = .vertical
        view.alignment = .leading
        view.translatesAutoresizingMaskIntoConstraints = false
        array.forEach { specialization in
            let button = UIButton()
            button.height(44)
            button.setTitleColor(.blue, for: .normal)
            button.translatesAutoresizingMaskIntoConstraints = false
            button.setTitle(specialization, for: .normal)
            button.addTarget(self, action: #selector(specializationDidTap), for: .touchUpInside)
            view.addArrangedSubview(button)
        }
        let vc = VCFactory.buildBottomSheetController(
            with: view,
            onEveryTapOut: nil
        )
        present(vc, animated: true, completion: nil)
    }
    
    var profile: Profile? {
        didSet {
            contentView.fillWith(profile: profile)
            contentView.profile = profile
        }
    }
    
}
