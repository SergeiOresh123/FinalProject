//
//  SettingsService.swift
//  SchoolStore
//
//  Created by Heads on 04.11.2021.
//

import Foundation

protocol SettingsService: AnyObject {
    func userChange(name: String, surname: String, occupation: String, avatar: String?,  completion: ((Result<Void, Error>) -> Void)?)
    
}

final class SettingsServiceImpl: SettingsService {
    
    init(networkProvider: NetworkProvider, dataService: DataService) {
        self.networkProvider = networkProvider
        self.dataService = dataService
    }
    
    typealias UserChange = DataResponse<ProfileResponse>
    
    func userChange(name: String, surname: String, occupation: String, avatar: String?,  completion: ((Result<Void, Error>) -> Void)?) {
        networkProvider.mock(UserRequest.userChange(name: name, surname: surname, occupation: occupation, avatar: avatar), completion: { (result: Result<UserChange, Error>) in
            switch result {
            case .success:
                completion?(Result.success(()))
            case let .failure(error):
                completion?(Result.failure(error))
            }
        })
    }
    
    private let networkProvider: NetworkProvider
    private let dataService: DataService
    
}
