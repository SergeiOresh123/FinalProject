//
//  OrderService.swift
//  SchoolStore
//
//  Created by Heads on 03.11.2021.
//

import Foundation

protocol OrderService: AnyObject {
    func orderCheckout(productId: String, size: String, quantity: String, house: String, apartment: String, etd: String, completion: ((Result<Void, Error>) -> Void)?)
    
}

final class OrderServiceImpl: OrderService {
    
    init(networkProvider: NetworkProvider, dataService: DataService) {
        self.networkProvider = networkProvider
        self.dataService = dataService
    }
    
    typealias OrderSent = DataResponse<OrderCheckout>
    
    func orderCheckout(productId: String, size: String, quantity: String, house: String, apartment: String, etd: String, completion: ((Result<Void, Error>) -> Void)?) {
        networkProvider.mock(OrdersRequest.arrangeOrder(productId: productId, size: size, quantity: quantity, house: house, apartment: apartment, etd: etd), completion: { (result: Result<OrderSent, Error>) in
            switch result {
            case .success:
                completion?(Result.success(()))
            case let .failure(error):
                completion?(Result.failure(error))
            }
        })
    }
    
    
    
    private let networkProvider: NetworkProvider
    private let dataService: DataService
    
}
