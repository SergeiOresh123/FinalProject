// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  /// Plural format key: "%#@VARIABLE@"
  internal static func ageValue(_ p1: Int) -> String {
    return L10n.tr("Localizable", "age-value", p1)
  }

  internal enum Auth {
    /// Войти
    internal static let action = L10n.tr("Localizable", "auth.action")
    /// Логин
    internal static let login = L10n.tr("Localizable", "auth.login")
    /// Пароль
    internal static let password = L10n.tr("Localizable", "auth.password")
  }

  internal enum Catalog {
    /// Купить
    internal static let buy = L10n.tr("Localizable", "catalog.buy")
    /// Каталог
    internal static let title = L10n.tr("Localizable", "catalog.title")
  }

  internal enum Checkout {
    /// Оформить заказ
    internal static let title = L10n.tr("Localizable", "checkout.title")
  }

  internal enum Common {
    /// Поле пустое
    internal static let emptyField = L10n.tr("Localizable", "common.emptyField")
    /// Что-то пошло не так
    internal static let error = L10n.tr("Localizable", "common.error")
  }

  internal enum History {
  
    internal static let title = L10n.tr("Localizable", "history.title")
  }
    
  internal enum Edit {
     
    internal static let action = L10n.tr("Localizable", "edit.action")
  }
  
  internal enum Profile {
       
    internal static let title = L10n.tr("Localizable", "profile.title")
    
  }
    
  internal enum Settings {
       
     internal static let title = L10n.tr("Localizable", "settings.title")
    
  }
    
  internal enum Order {
   
     internal static let house = L10n.tr("Localizable", "order.house")
     
     internal static let apartment = L10n.tr("Localizable", "order.apartment")
   
     internal static let date = L10n.tr("Localizable", "order.date")
     
     internal static let address = L10n.tr("Localizable", "order.address")
    
     internal static let number = L10n.tr("Localizable", "order.number")
    
     internal static let from = L10n.tr("Localizable", "order.from")
    
     internal static let at = L10n.tr("Localizable", "order.at")
    
    }
    
  internal enum EditProfile {
     
     internal static let name = L10n.tr("Localizable", "editProfile.name")
       
     internal static let surname = L10n.tr("Localizable", "editProfile.surname")
     
     internal static let occupation = L10n.tr("Localizable", "editProfile.occupation")
    
     internal static let occupationOther = L10n.tr("Localizable", "editProfile.occupationOther")
      }
    
   internal enum Btn {
     
     internal static let change = L10n.tr("Localizable", "btn.change")
       
     internal static let buy = L10n.tr("Localizable", "btn.buy")
    
     internal static let buyPrice = L10n.tr("Localizable", "btn.buyPrice")
    
     internal static let back = L10n.tr("Localizable", "btn.back")
    
     internal static let logout = L10n.tr("Localizable", "btn.logout")
     
    }
    
   internal enum Alert {
     
     internal static let cancel = L10n.tr("Localizable", "alert.cancel")
       
     internal static let back = L10n.tr("Localizable", "alert.back")
     
     internal static let title = L10n.tr("Localizable", "alert.title")
     
    }
    
   internal enum Segmentedcontrol {
      
     internal static let all = L10n.tr("Localizable", "segmentedcontrol.all")
        
     internal static let active = L10n.tr("Localizable", "segmentedcontrol.active")
     
    }
    
    
    
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg...) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: nil, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
